% Function that initializes the separation vector 
function E = init_E (N)
E = zeros(2*N+1,1) ; % separation vector 
E(1) = 1 ;
end